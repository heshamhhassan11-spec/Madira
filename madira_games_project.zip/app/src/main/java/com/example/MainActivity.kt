package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ChallengeItem
import com.example.data.repository.AppDataRepository
import com.example.ui.components.AppBottomNavigation
import com.example.ui.components.AppNavDestination
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChallengesMainScreen
import com.example.ui.screens.ClubGuessScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.PlayerGuessScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SquadBuilderScreen
import com.example.ui.screens.StockMarketScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.theme.DarkAppBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    FootballChallengesApp()
                }
            }
        }
    }
}

@Composable
fun FootballChallengesApp() {
    val repository = remember { AppDataRepository() }

    // User session state
    var isAuthenticated by remember { mutableStateOf(false) }

    // Navigation state
    var currentDestination by remember { mutableStateOf(AppNavDestination.CHALLENGES) }
    var activeChallenge by remember { mutableStateOf<ChallengeItem?>(null) }

    // Eye Comfort Font Scale (1.0f = normal, 1.15f = large, 1.3f = extra large)
    var fontScale by remember { mutableFloatStateOf(1.0f) }

    // Observed Data
    val currentUser by repository.currentUser.collectAsState()
    val challenges by repository.challenges.collectAsState()
    val leaderboard by repository.leaderboard.collectAsState()
    val stocks by repository.stocks.collectAsState()
    val transactions by repository.transactions.collectAsState()

    val favoriteChallenges = remember(challenges) {
        challenges.filter { it.isFavorite }
    }

    if (!isAuthenticated) {
        // First screen is Login & Registration with Facebook & Google
        AuthScreen(
            onLoginSuccess = { name, email ->
                repository.login(email = email, name = name)
                isAuthenticated = true
            },
            fontScale = fontScale
        )
    } else if (activeChallenge != null) {
        // Active challenge playable screens
        when (activeChallenge?.id) {
            "guess_player" -> {
                PlayerGuessScreen(
                    questions = repository.playerQuestions,
                    onBack = { activeChallenge = null },
                    onAddScore = { points -> repository.addPoints(points) },
                    fontScale = fontScale
                )
            }
            "guess_club" -> {
                ClubGuessScreen(
                    questions = repository.clubQuestions,
                    onBack = { activeChallenge = null },
                    onAddScore = { points -> repository.addPoints(points) },
                    fontScale = fontScale
                )
            }
            "squad_builder" -> {
                SquadBuilderScreen(
                    playersPool = repository.squadPlayersPool,
                    onBack = { activeChallenge = null },
                    onSubmitSquad = { rating, chemistry ->
                        repository.addPoints(rating + (chemistry / 2))
                    },
                    fontScale = fontScale
                )
            }
            "stock_market" -> {
                StockMarketScreen(
                    stocks = stocks,
                    userCoins = currentUser.virtualCoins,
                    onBuy = { stockId, count -> repository.buyStock(stockId, count) },
                    onSell = { stockId, count -> repository.sellStock(stockId, count) },
                    onBack = { activeChallenge = null },
                    fontScale = fontScale
                )
            }
            else -> {
                activeChallenge = null
            }
        }
    } else {
        // Main scaffold with bottom navigation
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkAppBackground),
            containerColor = DarkAppBackground,
            bottomBar = {
                AppBottomNavigation(
                    currentDestination = currentDestination,
                    onNavigate = { destination -> currentDestination = destination },
                    favoritesCount = favoriteChallenges.size,
                    isVip = currentUser.isVip,
                    fontScale = fontScale
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentDestination) {
                    AppNavDestination.CHALLENGES -> {
                        ChallengesMainScreen(
                            challenges = challenges,
                            onChallengeSelected = { challenge -> activeChallenge = challenge },
                            onToggleFavorite = { challengeId -> repository.toggleFavorite(challengeId) },
                            fontScale = fontScale,
                            onFontScaleChange = { newScale -> fontScale = newScale },
                            userPoints = currentUser.points
                        )
                    }
                    AppNavDestination.LEADERBOARD -> {
                        LeaderboardScreen(
                            leaderboard = leaderboard,
                            fontScale = fontScale
                        )
                    }
                    AppNavDestination.FAVORITES -> {
                        FavoritesScreen(
                            favoriteChallenges = favoriteChallenges,
                            onChallengeSelected = { challenge -> activeChallenge = challenge },
                            onToggleFavorite = { challengeId -> repository.toggleFavorite(challengeId) },
                            fontScale = fontScale
                        )
                    }
                    AppNavDestination.VIP_SUBSCRIPTION -> {
                        SubscriptionScreen(
                            isVip = currentUser.isVip,
                            recentTransactions = transactions,
                            onProcessPayment = { method, target, sender, ref ->
                                repository.processSubscription(method, target, sender, ref)
                            },
                            fontScale = fontScale
                        )
                    }
                    AppNavDestination.PROFILE -> {
                        ProfileScreen(
                            user = currentUser,
                            fontScale = fontScale,
                            onFontScaleChange = { newScale -> fontScale = newScale },
                            onSignOut = { isAuthenticated = false },
                            onNavigateToSubscription = { currentDestination = AppNavDestination.VIP_SUBSCRIPTION },
                            onNavigateToChallenges = { currentDestination = AppNavDestination.CHALLENGES }
                        )
                    }
                }
            }
        }
    }
}
