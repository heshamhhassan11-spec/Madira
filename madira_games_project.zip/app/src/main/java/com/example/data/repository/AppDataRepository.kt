package com.example.data.repository

import com.example.data.model.ChallengeCategory
import com.example.data.model.ChallengeDifficulty
import com.example.data.model.ChallengeIconType
import com.example.data.model.ChallengeItem
import com.example.data.model.ClubGuessQuestion
import com.example.data.model.LeaderboardEntry
import com.example.data.model.PaymentTransaction
import com.example.data.model.PlayerGuessQuestion
import com.example.data.model.PlayerStock
import com.example.data.model.SquadPlayer
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AppDataRepository {

    // Current logged-in user profile
    private val _currentUser = MutableStateFlow(
        UserProfile(
            id = "usr_101",
            name = "كابتن زياد",
            email = "ziad.football@gmail.com",
            avatarEmoji = "⚽",
            points = 2850,
            rank = 4,
            winStreak = 7,
            isVip = false,
            favoriteClub = "الأهلي المصري",
            virtualCoins = 15000.0
        )
    )
    val currentUser: StateFlow<UserProfile> = _currentUser.asStateFlow()

    // Challenges list with favorites tracking
    private val _challenges = MutableStateFlow(
        listOf(
            ChallengeItem(
                id = "guess_player",
                title = "خمن اسم اللاعب",
                description = "تعرف على أساطير ونجوم الساحرة المستديرة من خلال الأندية والجنسية والأرقام والإنجازات التاريخية.",
                iconType = ChallengeIconType.PERSON,
                difficulty = ChallengeDifficulty.EASY,
                category = ChallengeCategory.TRIVIA,
                isFavorite = false,
                rewardXp = 150,
                activePlayers = 4320
            ),
            ChallengeItem(
                id = "guess_club",
                title = "خمن اسم النادي",
                description = "اختبر معلوماتك الكروية عن كبار أندية أوروبا والعالم، الملاعب التاريخية، الألقاب والهتافات الشهيرة.",
                iconType = ChallengeIconType.SOCCER,
                difficulty = ChallengeDifficulty.MEDIUM,
                category = ChallengeCategory.TRIVIA,
                isFavorite = true,
                rewardXp = 200,
                activePlayers = 3890
            ),
            ChallengeItem(
                id = "squad_builder",
                title = "كون فريق",
                description = "ابنِ تشكيلة أحلامك بميزانية محددة، حقق أعلى معدل تناغم كروي (كيمستري) واقهر تشكيلات أصدقائك.",
                iconType = ChallengeIconType.GROUPS,
                difficulty = ChallengeDifficulty.HARD,
                category = ChallengeCategory.TACTICS,
                isFavorite = false,
                rewardXp = 350,
                activePlayers = 6120
            ),
            ChallengeItem(
                id = "stock_market",
                title = "تحدي البورصة",
                description = "اشترِ وبع أسهم نجوم الكرة وفقاً لمستوياتهم في المباريات الواقعية وحقق أرباحاً خيالية في محفظتك.",
                iconType = ChallengeIconType.TRENDING_UP,
                difficulty = ChallengeDifficulty.MEDIUM,
                category = ChallengeCategory.MARKET,
                isFavorite = false,
                rewardXp = 300,
                activePlayers = 5240
            )
        )
    )
    val challenges: StateFlow<List<ChallengeItem>> = _challenges.asStateFlow()

    // Leaderboard
    private val _leaderboard = MutableStateFlow(
        listOf(
            LeaderboardEntry(1, "محمد صلاح الدين", 4950, "👑", "ليفربول", isVip = true, weeklyWinRate = "94%"),
            LeaderboardEntry(2, "عمر الفاروق", 4320, "🥇", "ريال مدريد", isVip = true, weeklyWinRate = "89%"),
            LeaderboardEntry(3, "يوسف مروان", 3890, "🥈", "مانشستر سيتي", isVip = true, weeklyWinRate = "85%"),
            LeaderboardEntry(4, "كابتن زياد (أنت)", 2850, "⚽", "الأهلي المصري", isVip = false, isCurrentUser = true, weeklyWinRate = "78%"),
            LeaderboardEntry(5, "كريم حازم", 2610, "🔥", "برشلونة", isVip = false, weeklyWinRate = "74%"),
            LeaderboardEntry(6, "أحمد عاشور", 2430, "⚡", "الزمالك", isVip = false, weeklyWinRate = "71%"),
            LeaderboardEntry(7, "محمود الجوكر", 2150, "🎯", "أرسنال", isVip = false, weeklyWinRate = "68%"),
            LeaderboardEntry(8, "طارق الشناوي", 1920, "🧤", "بايرن ميونخ", isVip = false, weeklyWinRate = "65%")
        )
    )
    val leaderboard: StateFlow<List<LeaderboardEntry>> = _leaderboard.asStateFlow()

    // Payment transactions history
    private val _transactions = MutableStateFlow<List<PaymentTransaction>>(emptyList())
    val transactions: StateFlow<List<PaymentTransaction>> = _transactions.asStateFlow()

    // Questions for "Guess Player"
    val playerQuestions = listOf(
        PlayerGuessQuestion(
            id = 1,
            hintNationality = "🇪🇬 مصر",
            hintClubs = listOf("المقاولون العرب", "بازل", "تشيلسي", "روما", "ليفربول"),
            hintNumber = 11,
            hintPosition = "جناح أيمن",
            specialClue = "أفضل هداف أفريقي في تاريخ الدوري الإنجليزي الممتاز والملك المصري 👑",
            correctAnswer = "محمد صلاح",
            options = listOf("محمد صلاح", "عمر مرموش", "محمود تريزيجيه", "رياض محرز")
        ),
        PlayerGuessQuestion(
            id = 2,
            hintNationality = "🇦🇷 الأرجنتين",
            hintClubs = listOf("برشلونة", "باريس سان جيرمان", "إنتر ميامي"),
            hintNumber = 10,
            hintPosition = "صانع ألعاب / مهاجم",
            specialClue = "حاصل على 8 كرات ذهبية وبطل كأس العالم قطر 2022 🏆",
            correctAnswer = "ليونيل ميسي",
            options = listOf("سيرجيو أجويرو", "ليونيل ميسي", "باولو ديبالا", "أنخيل دي ماريا")
        ),
        PlayerGuessQuestion(
            id = 3,
            hintNationality = "🇵🇹 البرتغال",
            hintClubs = listOf("سبورتينغ لشبونة", "مانشستر يونايتد", "ريال مدريد", "يوفنتوس", "النصر"),
            hintNumber = 7,
            hintPosition = "مهاجم",
            specialClue = "الهداف التاريخي لكرة القدم وبطولة دوري أبطال أوروبا وصاحب احتفال SIUUU 💥",
            correctAnswer = "كريستيانو رونالدو",
            options = listOf("برونو فيرنانديز", "جواو فيليكس", "كريستيانو رونالدو", "لويس ناني")
        ),
        PlayerGuessQuestion(
            id = 4,
            hintNationality = "🇳🇴 النرويج",
            hintClubs = listOf("مولده", "سالزبورغ", "بوروسيا دورتموند", "مانشستر سيتي"),
            hintNumber = 9,
            hintPosition = "مهاجم صريح",
            specialClue = "الدبابة الاسكندنافية ومحطم الرقم القياسي للأهداف في موسم واحد بالبريميرليغ 🤖",
            correctAnswer = "إيرلينغ هالاند",
            options = listOf("مارتن أوديغارد", "ألكسندر إيزاك", "إيرلينغ هالاند", "فيكتور جيوكيريس")
        ),
        PlayerGuessQuestion(
            id = 5,
            hintNationality = "🇧🇷 البرازيل",
            hintClubs = listOf("فلامنغو", "ريال مدريد"),
            hintNumber = 7,
            hintPosition = "جناح أيسر",
            specialClue = "نجم السامبا صاحب أهداف الحسم في نهائيات دوري أبطال أوروبا ومراوغات الساحر ⚡",
            correctAnswer = "فينيسيوس جونيور",
            options = listOf("رودريغو", "فينيسيوس جونيور", "نيمار داسيلفا", "رافينيا")
        )
    )

    // Questions for "Guess Club"
    val clubQuestions = listOf(
        ClubGuessQuestion(
            id = 1,
            country = "🇪🇸 إسبانيا",
            stadium = "سانتياغو برنابيو",
            titlesCount = "15 لقباً في دوري أبطال أوروبا",
            famousLegend = "ألفريدو دي ستيفانو / زين الدين زيدان",
            nickname = "الميرنغي (الملكي)",
            correctAnswer = "ريال مدريد",
            options = listOf("ريال مدريد", "برشلونة", "أتلتيكو مدريد", "فالنسيا")
        ),
        ClubGuessQuestion(
            id = 2,
            country = "🇪🇬 مصر",
            stadium = "ستاد القاهرة الدولي",
            titlesCount = "12 لقباً في دوري أبطال أفريقيا",
            famousLegend = "محمود الخطيب / محمد أبو تريكة",
            nickname = "نادي القرن الإفريقي / الشياطين الحمر",
            correctAnswer = "الأهلي المصري",
            options = listOf("الزمالك", "الأهلي المصري", "الإسماعيلي", "بيراميدز")
        ),
        ClubGuessQuestion(
            id = 3,
            country = "🏴󠁧󠁢󠁥󠁮󠁧󠁿 إنجلترا",
            stadium = "الأنفيلد (Anfield)",
            titlesCount = "6 ألقاب دوري أبطال أوروبا و 19 دوري إنجليزي",
            famousLegend = "ستيفن جيرارد / كيني دالغليش",
            nickname = "الريدز (You'll Never Walk Alone)",
            correctAnswer = "ليفربول",
            options = listOf("مانشستر يونايتد", "أرسنال", "ليفربول", "تشيلسي")
        ),
        ClubGuessQuestion(
            id = 4,
            country = "🇮🇹 إيطاليا",
            stadium = "سان سيرو (جوزيبي مياتزا)",
            titlesCount = "7 ألقاب في دوري أبطال أوروبا",
            famousLegend = "باولو مالديني / فرانكو باريزي",
            nickname = "الروسونيري",
            correctAnswer = "إيه سي ميلان",
            options = listOf("يوفنتوس", "إنتر ميلان", "إيه سي ميلان", "روما")
        )
    )

    // Available players for Squad Builder
    val squadPlayersPool = listOf(
        SquadPlayer("p1", "تيبو كورتوا", "GK", 90, 8.5, "بلجيكا", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p2", "محمد الشناوي", "GK", 82, 3.0, "مصر", "الأهلي", "الدوري المصري"),
        SquadPlayer("p3", "أليسون بيكر", "GK", 89, 8.0, "البرازيل", "ليفربول", "البريميرليغ"),

        SquadPlayer("p4", "فيررجيل فان دايك", "DEF", 90, 9.5, "هولندا", "ليفربول", "البريميرليغ"),
        SquadPlayer("p5", "أنطونيو روديغر", "DEF", 88, 7.5, "ألمانيا", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p6", "أشرف حكيمي", "DEF", 87, 8.0, "المغرب", "باريس سان جيرمان", "الدوري الفرنسي"),
        SquadPlayer("p7", "ألفونسو ديفيز", "DEF", 86, 7.0, "كندا", "بايرن ميونخ", "البوندسليغا"),
        SquadPlayer("p8", "محمد عبد المنعم", "DEF", 80, 2.5, "مصر", "نيس", "الدوري الفرنسي"),

        SquadPlayer("p9", "جود بيلينجهام", "MID", 91, 12.0, "إنجلترا", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p10", "رودري هرنانديز", "MID", 91, 11.5, "إسبانيا", "مانشستر سيتي", "البريميرليغ"),
        SquadPlayer("p11", "كيفين دي بروين", "MID", 90, 10.0, "بلجيكا", "مانشستر سيتي", "البريميرليغ"),
        SquadPlayer("p12", "لوكا مودريتش", "MID", 87, 5.0, "كرواتيا", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p13", "إمام عاشور", "MID", 82, 3.5, "مصر", "الأهلي", "الدوري المصري"),

        SquadPlayer("p14", "محمد صلاح", "FWD", 91, 13.0, "مصر", "ليفربول", "البريميرليغ"),
        SquadPlayer("p15", "كيليان مبابي", "FWD", 92, 15.0, "فرنسا", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p16", "إيرلينغ هالاند", "FWD", 92, 14.5, "النرويج", "مانشستر سيتي", "البريميرليغ"),
        SquadPlayer("p17", "فينيسيوس جونيور", "FWD", 91, 13.5, "البرازيل", "ريال مدريد", "لا ليغا"),
        SquadPlayer("p18", "لامين يامال", "FWD", 87, 10.5, "إسبانيا", "برشلونة", "لا ليغا"),
        SquadPlayer("p19", "وسام أبو علي", "FWD", 81, 2.8, "فلسطين", "الأهلي", "الدوري المصري")
    )

    // Player Stocks in the Market
    private val _stocks = MutableStateFlow(
        listOf(
            PlayerStock("s1", "محمد صلاح", "ليفربول", 485.0, +6.4, "سجل هدفين وصنع هدف ضد السيتي", true, ownedShares = 5),
            PlayerStock("s2", "فينيسيوس جونيور", "ريال مدريد", 420.0, +3.8, "هاتريك في الكلاسيكو وأداء مذهل", true, ownedShares = 2),
            PlayerStock("s3", "كيليان مبابي", "ريال مدريد", 460.0, -2.1, "إهدار ركلة جزاء في اللقاء الأخير", false, ownedShares = 0),
            PlayerStock("s4", "إيرلينغ هالاند", "مانشستر سيتي", 495.0, +4.5, "هدفان وحسم نقاط المباراة الصعبة", true, ownedShares = 3),
            PlayerStock("s5", "لامين يامال", "برشلونة", 360.0, +8.2, "أصغر ممرر حاسم وجائزة رجل المباراة", true, ownedShares = 10),
            PlayerStock("s6", "جود بيلينجهام", "ريال مدريد", 410.0, -1.5, "إنذار وتراجع طفيف في صناعة الفرص", false, ownedShares = 1),
            PlayerStock("s7", "عمر مرموش", "آينتراخت فرانكفورت", 295.0, +11.3, "ثلاث ركلات حرة متتالية في الشباك 🔥", true, ownedShares = 4)
        )
    )
    val stocks: StateFlow<List<PlayerStock>> = _stocks.asStateFlow()

    fun toggleFavorite(challengeId: String) {
        _challenges.update { list ->
            list.map { item ->
                if (item.id == challengeId) item.copy(isFavorite = !item.isFavorite) else item
            }
        }
    }

    fun addPoints(amount: Int) {
        _currentUser.update { user ->
            val newPoints = user.points + amount
            val newRank = when {
                newPoints > 4500 -> 1
                newPoints > 4000 -> 2
                newPoints > 3500 -> 3
                else -> 4
            }
            user.copy(points = newPoints, rank = newRank)
        }
    }

    fun buyStock(stockId: String, count: Int = 1): Boolean {
        val stock = _stocks.value.find { it.id == stockId } ?: return false
        val totalCost = stock.currentPriceEgp * count
        if (_currentUser.value.virtualCoins < totalCost) return false

        _currentUser.update { it.copy(virtualCoins = it.virtualCoins - totalCost) }
        _stocks.update { list ->
            list.map {
                if (it.id == stockId) it.copy(ownedShares = it.ownedShares + count) else it
            }
        }
        return true
    }

    fun sellStock(stockId: String, count: Int = 1): Boolean {
        val stock = _stocks.value.find { it.id == stockId } ?: return false
        if (stock.ownedShares < count) return false
        val totalRevenue = stock.currentPriceEgp * count

        _currentUser.update { it.copy(virtualCoins = it.virtualCoins + totalRevenue) }
        _stocks.update { list ->
            list.map {
                if (it.id == stockId) it.copy(ownedShares = it.ownedShares - count) else it
            }
        }
        return true
    }

    fun processSubscription(
        method: String,
        targetNumber: String,
        senderNumber: String,
        referenceId: String
    ): PaymentTransaction {
        val transaction = PaymentTransaction(
            id = "TXN_${System.currentTimeMillis().toString().takeLast(6)}",
            method = method,
            targetNumber = targetNumber,
            senderNumber = senderNumber,
            referenceId = referenceId,
            amountEgp = 30,
            status = "مكتمل وتم تفعيل اشتراك VIP الشهري"
        )
        _transactions.update { listOf(transaction) + it }
        _currentUser.update { it.copy(isVip = true, points = it.points + 500) }
        // Update user on leaderboard as well
        _leaderboard.update { entries ->
            entries.map {
                if (it.isCurrentUser) it.copy(isVip = true, points = it.points + 500) else it
            }
        }
        return transaction
    }

    fun login(email: String, name: String) {
        _currentUser.update {
            it.copy(
                email = email.ifBlank { "user@football.com" },
                name = name.ifBlank { "كابتن الكرة" }
            )
        }
    }
}
