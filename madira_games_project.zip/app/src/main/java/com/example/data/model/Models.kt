package com.example.data.model

enum class ChallengeIconType {
    PERSON,
    SOCCER,
    GROUPS,
    TRENDING_UP
}

enum class ChallengeDifficulty(val labelAr: String) {
    EASY("سهل"),
    MEDIUM("متوسط"),
    HARD("صعب")
}

enum class ChallengeCategory(val labelAr: String) {
    ALL("الكل"),
    TRIVIA("معلومات كروية"),
    TACTICS("تكتيك وتشكيل"),
    MARKET("سوق وبورصة")
}

data class ChallengeItem(
    val id: String,
    val title: String,
    val description: String,
    val iconType: ChallengeIconType,
    val difficulty: ChallengeDifficulty,
    val category: ChallengeCategory,
    val isFavorite: Boolean = false,
    val rewardXp: Int = 100,
    val activePlayers: Int = 1240,
    val isPremiumOnly: Boolean = false
)

data class FootballRankTier(
    val tierId: String,
    val titleAr: String,
    val badgeIconEmoji: String,
    val minPoints: Int,
    val maxPoints: Int,
    val badgeColorHex: Long = 0xFFFFD700,
    val perkDescriptionAr: String
)

val FOOTBALL_TIERS = listOf(
    FootballRankTier(
        tierId = "tier_rookie",
        titleAr = "لاعب مبتدئ",
        badgeIconEmoji = "🌱",
        minPoints = 0,
        maxPoints = 999,
        badgeColorHex = 0xFF81C784,
        perkDescriptionAr = "فتح التحديات الكروية الأساسية وتجربة المسابقات"
    ),
    FootballRankTier(
        tierId = "tier_talent",
        titleAr = "لاعب واعد",
        badgeIconEmoji = "⚡",
        minPoints = 1000,
        maxPoints = 2499,
        badgeColorHex = 0xFF64B5F6,
        perkDescriptionAr = "مكافأة +5% نقاط إضافية في الفوز وتكتيكات دفاعية جديدة"
    ),
    FootballRankTier(
        tierId = "tier_star",
        titleAr = "نجم الفريق",
        badgeIconEmoji = "🌟",
        minPoints = 2500,
        maxPoints = 4499,
        badgeColorHex = 0xFFFFD54F,
        perkDescriptionAr = "فتح صفقات حصرية في بورصة اللاعبين وشارات تميز"
    ),
    FootballRankTier(
        tierId = "tier_captain",
        titleAr = "قائد التشكيلة",
        badgeIconEmoji = "🛡️",
        minPoints = 4500,
        maxPoints = 7499,
        badgeColorHex = 0xFFFF7043,
        perkDescriptionAr = "فتح خطة 3-5-2 الهجومية ومضاعفة أرباح الأسهم"
    ),
    FootballRankTier(
        tierId = "tier_legend",
        titleAr = "أسطورة الملاعب",
        badgeIconEmoji = "👑",
        minPoints = 7500,
        maxPoints = 11999,
        badgeColorHex = 0xFFBA68C8,
        perkDescriptionAr = "بطولات مغلقة لكبار الأساطير وشارة التاج الذهبي"
    ),
    FootballRankTier(
        tierId = "tier_ballon_dor",
        titleAr = "الكرة الذهبية",
        badgeIconEmoji = "🏆",
        minPoints = 12000,
        maxPoints = Int.MAX_VALUE,
        badgeColorHex = 0xFFFFD700,
        perkDescriptionAr = "المرتبة الفخرية العليا ومضاعفة نقاط الصدارة للأبد"
    )
)

data class UserLevelProgress(
    val level: Int,
    val currentTier: FootballRankTier,
    val nextTier: FootballRankTier?,
    val currentPoints: Int,
    val levelStartPoints: Int,
    val levelNextPoints: Int,
    val levelProgressRatio: Float,
    val pointsToNextLevel: Int,
    val tierProgressRatio: Float,
    val pointsToNextTier: Int
)

fun calculateUserLevelProgress(points: Int): UserLevelProgress {
    val pointsPerLevel = 250
    val calculatedLevel = 1 + (points / pointsPerLevel)
    val levelStart = (calculatedLevel - 1) * pointsPerLevel
    val levelNext = calculatedLevel * pointsPerLevel
    val ptsInLevel = (points - levelStart).coerceAtLeast(0)
    val levelRatio = (ptsInLevel.toFloat() / pointsPerLevel.toFloat()).coerceIn(0f, 1f)
    val ptsToNextLvl = (levelNext - points).coerceAtLeast(0)

    val currentTierIndex = FOOTBALL_TIERS.indexOfLast { points >= it.minPoints }.coerceAtLeast(0)
    val currentTier = FOOTBALL_TIERS[currentTierIndex]
    val nextTier = FOOTBALL_TIERS.getOrNull(currentTierIndex + 1)

    val tierRange = if (currentTier.maxPoints == Int.MAX_VALUE) 5000 else (currentTier.maxPoints - currentTier.minPoints + 1)
    val ptsInTier = (points - currentTier.minPoints).coerceAtLeast(0)
    val tierRatio = (ptsInTier.toFloat() / tierRange.toFloat()).coerceIn(0f, 1f)
    val ptsToNextTier = if (nextTier != null) (nextTier.minPoints - points).coerceAtLeast(0) else 0

    return UserLevelProgress(
        level = calculatedLevel,
        currentTier = currentTier,
        nextTier = nextTier,
        currentPoints = points,
        levelStartPoints = levelStart,
        levelNextPoints = levelNext,
        levelProgressRatio = levelRatio,
        pointsToNextLevel = ptsToNextLvl,
        tierProgressRatio = tierRatio,
        pointsToNextTier = ptsToNextTier
    )
}

data class UserProfile(
    val id: String = "user_1",
    val name: String = "كابتن أحمد",
    val email: String = "ahmed.football@gmail.com",
    val avatarEmoji: String = "⚽",
    val points: Int = 3450,
    val rank: Int = 4,
    val winStreak: Int = 5,
    val isVip: Boolean = false,
    val favoriteClub: String = "الأهلي",
    val virtualCoins: Double = 10000.0
) {
    val levelProgress: UserLevelProgress
        get() = calculateUserLevelProgress(points)
}

data class LeaderboardEntry(
    val rank: Int,
    val name: String,
    val points: Int,
    val avatarEmoji: String,
    val favoriteClub: String,
    val isVip: Boolean = false,
    val isCurrentUser: Boolean = false,
    val weeklyWinRate: String = "85%"
)

data class PlayerGuessQuestion(
    val id: Int,
    val hintNationality: String,
    val hintClubs: List<String>,
    val hintNumber: Int,
    val hintPosition: String,
    val specialClue: String,
    val correctAnswer: String,
    val options: List<String>
)

data class ClubGuessQuestion(
    val id: Int,
    val country: String,
    val stadium: String,
    val titlesCount: String,
    val famousLegend: String,
    val nickname: String,
    val correctAnswer: String,
    val options: List<String>
)

data class SquadPlayer(
    val id: String,
    val name: String,
    val position: String, // GK, DEF, MID, FWD
    val rating: Int,
    val priceMillions: Double,
    val nationality: String,
    val club: String,
    val league: String
)

data class PlayerStock(
    val id: String,
    val playerName: String,
    val club: String,
    val currentPriceEgp: Double,
    val priceChangePercent: Double,
    val lastMatchStats: String,
    val isBullish: Boolean,
    val ownedShares: Int = 0
)

data class PaymentTransaction(
    val id: String,
    val method: String, // "Wallet" or "InstaPay"
    val targetNumber: String,
    val senderNumber: String,
    val referenceId: String,
    val amountEgp: Int = 30,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "مكتمل ومفعل"
)
