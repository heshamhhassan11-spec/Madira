package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.ripple
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChallengeCategory
import com.example.data.model.ChallengeDifficulty
import com.example.data.model.ChallengeIconType
import com.example.data.model.ChallengeItem
import com.example.ui.theme.DarkAppBackground
import com.example.ui.theme.DarkAppBarColor
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChallengesMainScreen(
    challenges: List<ChallengeItem>,
    onChallengeSelected: (ChallengeItem) -> Unit,
    onToggleFavorite: (String) -> Unit,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit,
    userPoints: Int = 2850,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<ChallengeCategory?>(null) }
    var selectedDifficulty by remember { mutableStateOf<ChallengeDifficulty?>(null) }
    var showFontDialog by remember { mutableStateOf(false) }

    // Filter challenges based on search, category, and difficulty
    val filteredChallenges = remember(challenges, searchQuery, selectedCategory, selectedDifficulty) {
        challenges.filter { challenge ->
            val matchesSearch = searchQuery.isBlank() ||
                challenge.title.contains(searchQuery, ignoreCase = true) ||
                challenge.description.contains(searchQuery, ignoreCase = true)
            val matchesCategory = selectedCategory == null || challenge.category == selectedCategory
            val matchesDifficulty = selectedDifficulty == null || challenge.difficulty == selectedDifficulty

            matchesSearch && matchesCategory && matchesDifficulty
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkAppBackground) // 0xFF1E1E2C as specified
            .testTag("challenges_main_screen")
    ) {
        // Top AppBar with color 0xFF2D2D44 and title "التحديات المجانية"
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.SportsSoccer,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "التحديات المجانية",
                        color = TextPrimary,
                        fontSize = (19 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            actions = {
                // Font Size Eye Comfort adjustment button
                IconButton(
                    onClick = {
                        val nextScale = when {
                            fontScale < 1.1f -> 1.15f
                            fontScale < 1.25f -> 1.3f
                            else -> 1.0f
                        }
                        onFontScaleChange(nextScale)
                    },
                    modifier = Modifier.testTag("btn_font_size_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.FormatSize,
                        contentDescription = "تغيير حجم الخط المريح",
                        tint = GoldPrimary
                    )
                }

                // Points Chip
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1E1E2C),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                    modifier = Modifier.padding(end = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "النقاط",
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "مستوى ${1 + (userPoints / 250)} • $userPoints ن",
                            color = GoldPrimary,
                            fontSize = (11.5 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DarkAppBarColor // 0xFF2D2D44 as specified
            )
        )

        // Upper Section: Search bar and Filters
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkAppBarColor)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Upper Search Bar to facilitate easy access to challenges
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = "ابحث عن تحدي كروي بالاسم أو الوصف...",
                        color = TextMuted,
                        fontSize = (13 * fontScale).sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = GoldPrimary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "مسح البحث",
                                tint = TextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_challenges_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF1E1E2C),
                    unfocusedContainerColor = Color(0xFF1E1E2C),
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = DarkCardBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Filters: Difficulty & Category Filter Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // "All" chip
                item {
                    val isAllSelected = selectedCategory == null && selectedDifficulty == null
                    FilterChip(
                        selected = isAllSelected,
                        onClick = {
                            selectedCategory = null
                            selectedDifficulty = null
                        },
                        label = {
                            Text(
                                "الكل (4)",
                                fontSize = (12 * fontScale).sp,
                                fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color(0xFF1E1E2C),
                            containerColor = Color(0xFF1E1E2C),
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isAllSelected,
                            borderColor = DarkCardBorder,
                            selectedBorderColor = GoldPrimary
                        )
                    )
                }

                // Difficulties: Easy, Medium, Hard
                items(ChallengeDifficulty.entries) { diff ->
                    val isSelected = selectedDifficulty == diff
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedDifficulty = if (isSelected) null else diff
                        },
                        label = {
                            Text(
                                diff.labelAr,
                                fontSize = (12 * fontScale).sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonGreen,
                            selectedLabelColor = Color(0xFF1E1E2C),
                            containerColor = Color(0xFF1E1E2C),
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = DarkCardBorder,
                            selectedBorderColor = NeonGreen
                        )
                    )
                }

                // Categories
                item {
                    val isTactics = selectedCategory == ChallengeCategory.TACTICS
                    FilterChip(
                        selected = isTactics,
                        onClick = {
                            selectedCategory = if (isTactics) null else ChallengeCategory.TACTICS
                        },
                        label = {
                            Text(
                                "تكتيك وتشكيل",
                                fontSize = (12 * fontScale).sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color(0xFF1E1E2C),
                            containerColor = Color(0xFF1E1E2C),
                            labelColor = TextSecondary
                        )
                    )
                }

                item {
                    val isMarket = selectedCategory == ChallengeCategory.MARKET
                    FilterChip(
                        selected = isMarket,
                        onClick = {
                            selectedCategory = if (isMarket) null else ChallengeCategory.MARKET
                        },
                        label = {
                            Text(
                                "سوق وبورصة",
                                fontSize = (12 * fontScale).sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GoldPrimary,
                            selectedLabelColor = Color(0xFF1E1E2C),
                            containerColor = Color(0xFF1E1E2C),
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // Subtitle & Count Info Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "اختر تحدياً وتنافس ضد أصدقائك:",
                color = TextSecondary,
                fontSize = (13 * fontScale).sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "حجم الخط المريح: ${if (fontScale > 1.2f) "كبير جداً" else if (fontScale > 1.05f) "كبير" else "عادي"}",
                color = TextMuted,
                fontSize = (11 * fontScale).sp
            )
        }

        // ListView.builder in Jetpack Compose: LazyColumn with Card items
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("challenges_list_view"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (filteredChallenges.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد تحديات مطابقة للبحث أو الفلتر المحدد.",
                            color = TextSecondary,
                            fontSize = (14 * fontScale).sp
                        )
                    }
                }
            } else {
                items(
                    items = filteredChallenges,
                    key = { it.id }
                ) { challenge ->
                    ChallengeCardItem(
                        item = challenge,
                        fontScale = fontScale,
                        onClick = { onChallengeSelected(challenge) },
                        onToggleFavorite = { onToggleFavorite(challenge.id) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun ChallengeCardItem(
    item: ChallengeItem,
    fontScale: Float,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    // Map icons strictly as requested:
    // 1. خمن اسم اللاعب -> Icons.Default.Person
    // 2. خمن اسم النادي -> Icons.Default.SportsSoccer
    // 3. كون فريق -> Icons.Default.Groups
    // 4. تحدي البورصة -> Icons.Default.TrendingUp
    val challengeIcon: ImageVector = when (item.iconType) {
        ChallengeIconType.PERSON -> Icons.Default.Person
        ChallengeIconType.SOCCER -> Icons.Default.SportsSoccer
        ChallengeIconType.GROUPS -> Icons.Default.Groups
        ChallengeIconType.TRENDING_UP -> Icons.Default.TrendingUp
    }

    val iconAccentColor = when (item.iconType) {
        ChallengeIconType.PERSON -> GoldPrimary
        ChallengeIconType.SOCCER -> NeonGreen
        ChallengeIconType.GROUPS -> Color(0xFF64B5F6)
        ChallengeIconType.TRENDING_UP -> Color(0xFFFFB74D)
    }

    val heartColor by animateColorAsState(
        targetValue = if (item.isFavorite) Color(0xFFFF5252) else TextMuted,
        label = "favoriteColorAnim"
    )

    // Card with color 0xFF2D2D44 as requested + ripple effect on click
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                onClick = onClick,
                indication = ripple(bounded = true, color = GoldPrimary),
                interactionSource = remember { MutableInteractionSource() }
            )
            .border(1.dp, DarkCardBorder, RoundedCornerShape(16.dp))
            .testTag("challenge_card_${item.id}"),
        colors = CardDefaults.cardColors(
            containerColor = DarkCardSurface // 0xFF2D2D44 as specified
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Challenge Specific Icon in rounded container
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1E1E2C))
                        .border(1.5.dp, iconAccentColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = challengeIcon,
                        contentDescription = item.title,
                        tint = iconAccentColor,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Title and Subtitle
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.title,
                            color = TextPrimary,
                            fontSize = (17 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Difficulty Tag
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when (item.difficulty) {
                                ChallengeDifficulty.EASY -> NeonGreen.copy(alpha = 0.2f)
                                ChallengeDifficulty.MEDIUM -> WarningAmber.copy(alpha = 0.2f)
                                ChallengeDifficulty.HARD -> Color(0xFFFF5252).copy(alpha = 0.2f)
                            }
                        ) {
                            Text(
                                text = item.difficulty.labelAr,
                                color = when (item.difficulty) {
                                ChallengeDifficulty.EASY -> NeonGreen
                                ChallengeDifficulty.MEDIUM -> WarningAmber
                                ChallengeDifficulty.HARD -> Color(0xFFFF5252)
                            },
                                fontSize = (10 * fontScale).sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.description,
                        color = TextSecondary,
                        fontSize = (12.5 * fontScale).sp,
                        lineHeight = (17 * fontScale).sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Favorite Bookmark Button
                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.testTag("btn_favorite_${item.id}")
                ) {
                    Icon(
                        imageVector = if (item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = if (item.isFavorite) "إزالة من المفضلة" else "حفظ في المفضلة",
                        tint = heartColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Bottom row inside card: XP reward, Active players, and interactive Arrow Forward IOS icon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1E1E2C).copy(alpha = 0.6f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "⭐ +${item.rewardXp} نقطة خبرة",
                        color = GoldPrimary,
                        fontSize = (11.5 * fontScale).sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "👥 ${item.activePlayers} لاعب متنافس",
                        color = TextSecondary,
                        fontSize = (11 * fontScale).sp
                    )
                }

                // Interactive Arrow Forward IOS icon as explicitly requested
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 6.dp)
                ) {
                    Text(
                        text = "ابدأ التحدي",
                        color = GoldPrimary,
                        fontSize = (12 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos, // Icons.arrow_forward_ios
                        contentDescription = "الانتقال للخطوة التالية",
                        tint = GoldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
