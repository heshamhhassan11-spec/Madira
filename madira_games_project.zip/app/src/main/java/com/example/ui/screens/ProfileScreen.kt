package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FOOTBALL_TIERS
import com.example.data.model.FootballRankTier
import com.example.data.model.UserProfile
import com.example.ui.theme.DarkAppBackground
import com.example.ui.theme.DarkAppBarColor
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    user: UserProfile,
    fontScale: Float,
    onFontScaleChange: (Float) -> Unit,
    onSignOut: () -> Unit,
    onNavigateToSubscription: () -> Unit,
    onNavigateToChallenges: () -> Unit = {}
) {
    val progress = user.levelProgress

    // Smooth animated progress bar values
    val animatedLevelProgress by animateFloatAsState(
        targetValue = progress.levelProgressRatio,
        animationSpec = tween(durationMillis = 800),
        label = "levelProgressAnim"
    )

    val animatedTierProgress by animateFloatAsState(
        targetValue = progress.tierProgressRatio,
        animationSpec = tween(durationMillis = 800),
        label = "tierProgressAnim"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkAppBackground)
            .testTag("profile_screen")
    ) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الملف الشخصي ومستوى اللاعب",
                        color = TextPrimary,
                        fontSize = (18 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkAppBarColor)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // User Avatar & Badges Header
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF242436))
                    .border(2.dp, GoldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(text = user.avatarEmoji, fontSize = 40.sp)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = user.name,
                    color = TextPrimary,
                    fontSize = (20 * fontScale).sp,
                    fontWeight = FontWeight.Black
                )
                if (user.isVip) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = "VIP",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = user.email,
                color = TextSecondary,
                fontSize = (12.5 * fontScale).sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF1E1E2C),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
            ) {
                Text(
                    text = "مشجع: ${user.favoriteClub} ⚽",
                    color = GoldPrimary,
                    fontSize = (11.5 * fontScale).sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // MAIN LEVELING & PROGRESS BARS SYSTEM CARD
            // ==========================================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("user_level_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    // Header of Level Card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = GoldPrimary.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "المستوى ${progress.level}",
                                        color = GoldPrimary,
                                        fontSize = (14 * fontScale).sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(progress.currentTier.badgeColorHex).copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(progress.currentTier.badgeColorHex))
                            ) {
                                Text(
                                    text = "${progress.currentTier.badgeIconEmoji} ${progress.currentTier.titleAr}",
                                    color = Color(progress.currentTier.badgeColorHex),
                                    fontSize = (12.5 * fontScale).sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }

                        // Total Points Badge
                        Text(
                            text = "${user.points} نقطة",
                            color = TextPrimary,
                            fontSize = (13.5 * fontScale).sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // ------------------------------------------------------------------
                    // Progress Bar 1: التقدم نحو المستوى التالي (Next Level Progress Bar)
                    // ------------------------------------------------------------------
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "التقدم نحو المستوى ${progress.level + 1}",
                            color = TextPrimary,
                            fontSize = (13 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${progress.currentPoints} / ${progress.levelNextPoints} ن (${(progress.levelProgressRatio * 100).toInt()}%)",
                            color = GoldPrimary,
                            fontSize = (12 * fontScale).sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { animatedLevelProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .testTag("level_progress_bar"),
                        color = GoldPrimary,
                        trackColor = Color(0xFF1E1E2C),
                        strokeCap = StrokeCap.Round
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🎯 متبقي ${progress.pointsToNextLevel} نقطة للصعود للمستوى التالي",
                            color = TextSecondary,
                            fontSize = (11.5 * fontScale).sp
                        )
                        Text(
                            text = "+250 ن/مستوى",
                            color = TextMuted,
                            fontSize = (10.5 * fontScale).sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // ------------------------------------------------------------------
                    // Progress Bar 2: التقدم نحو الرتبة الكروية القادمة (Next Football Tier)
                    // ------------------------------------------------------------------
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(DarkCardBorder)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (progress.nextTier != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "الرتبة القادمة: ",
                                    color = TextPrimary,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${progress.nextTier.badgeIconEmoji} ${progress.nextTier.titleAr}",
                                    color = Color(progress.nextTier.badgeColorHex),
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Text(
                                text = "${(progress.tierProgressRatio * 100).toInt()}%",
                                color = Color(progress.nextTier.badgeColorHex),
                                fontSize = (12 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { animatedTierProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .testTag("tier_progress_bar"),
                            color = Color(progress.nextTier.badgeColorHex),
                            trackColor = Color(0xFF1E1E2C),
                            strokeCap = StrokeCap.Round
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "🏆 متبقي ${progress.pointsToNextTier} نقطة خبرة لفتح رتبة \"${progress.nextTier.titleAr}\"",
                            color = TextSecondary,
                            fontSize = (11.5 * fontScale).sp
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "أنت في أعلى رتبة كروية (الكرة الذهبية) 👑",
                                color = GoldPrimary,
                                fontSize = (12.5 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Current Tier Perk Note
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E1E2C)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "🎁", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "ميزة رتبتك الحالية (${progress.currentTier.titleAr}):",
                                    color = GoldPrimary,
                                    fontSize = (11 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = progress.currentTier.perkDescriptionAr,
                                    color = TextSecondary,
                                    fontSize = (11 * fontScale).sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ==========================================
            // FOOTBALL TIERS ROADMAP & PERKS
            // ==========================================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("football_tiers_roadmap"),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎖️ مسار الرتب الكروية والجوائز:",
                        color = GoldPrimary,
                        fontSize = (14 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    FOOTBALL_TIERS.forEach { tier ->
                        val isUnlocked = user.points >= tier.minPoints
                        val isCurrent = user.points >= tier.minPoints && user.points <= tier.maxPoints

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isCurrent) GoldPrimary.copy(alpha = 0.15f)
                                    else if (isUnlocked) Color(0xFF1E1E2C)
                                    else Color(0xFF1A1A24)
                                )
                                .border(
                                    1.dp,
                                    if (isCurrent) GoldPrimary else DarkCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = tier.badgeIconEmoji, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = tier.titleAr,
                                            color = if (isUnlocked) TextPrimary else TextMuted,
                                            fontSize = (13 * fontScale).sp,
                                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Bold
                                        )
                                        if (isCurrent) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = GoldPrimary
                                            ) {
                                                Text(
                                                    text = "رتبتك الحالية",
                                                    color = Color.Black,
                                                    fontSize = (9 * fontScale).sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                    Text(
                                        text = tier.perkDescriptionAr,
                                        color = if (isUnlocked) TextSecondary else TextMuted,
                                        fontSize = (11 * fontScale).sp
                                    )
                                }
                            }

                            if (isUnlocked) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "تم فتح الرتبة",
                                    tint = NeonGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "مغلق",
                                        tint = TextMuted,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${tier.minPoints} ن",
                                        color = TextMuted,
                                        fontSize = (11 * fontScale).sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick CTA to play challenges and earn points
                    Button(
                        onClick = onNavigateToChallenges,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("btn_earn_points_cta"),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF1E1E2C))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "العب التحديات واكسب المزيد من النقاط ⚽",
                                color = Color(0xFF1E1E2C),
                                fontSize = (13 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // User Stats Grid (Points, Rank, Streak)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📊 إحصائياتك وسجل الفوز:",
                        color = GoldPrimary,
                        fontSize = (13.5 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        ProfileStatItem(
                            icon = Icons.Default.Star,
                            label = "النقاط الإجمالية",
                            value = "${user.points}",
                            accentColor = GoldPrimary,
                            fontScale = fontScale
                        )

                        ProfileStatItem(
                            icon = Icons.Default.EmojiEvents,
                            label = "الترتيب العام",
                            value = "#${user.rank}",
                            accentColor = NeonGreen,
                            fontScale = fontScale
                        )

                        ProfileStatItem(
                            icon = Icons.Default.LocalFireDepartment,
                            label = "سلسلة الانتصارات",
                            value = "${user.winStreak} مباريات",
                            accentColor = Color(0xFFFF7043),
                            fontScale = fontScale
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Eye Comfort Font Size Settings Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FormatSize,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "التحكم في حجم الخط المريح للعين:",
                            color = TextPrimary,
                            fontSize = (13.5 * fontScale).sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "المستوى الحالي: ${if (fontScale > 1.2f) "كبير جداً (1.3x)" else if (fontScale > 1.05f) "كبير (1.15x)" else "عادي (1.0x)"}",
                        color = TextSecondary,
                        fontSize = (12 * fontScale).sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Slider(
                        value = fontScale,
                        onValueChange = { onFontScaleChange(it) },
                        valueRange = 1.0f..1.3f,
                        steps = 2,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldPrimary,
                            activeTrackColor = GoldPrimary,
                            inactiveTrackColor = DarkCardBorder
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // VIP Upgrade Card
            if (!user.isVip) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2C2418)),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, GoldPrimary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "اشترك في VIP بـ 30 جنيه شهرياً",
                                color = GoldPrimary,
                                fontSize = (13.5 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "ادفع عبر فودافون كاش أو إنستاباي",
                                color = TextSecondary,
                                fontSize = (11.5 * fontScale).sp
                            )
                        }

                        Button(
                            onClick = onNavigateToSubscription,
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("ترقية الآن", color = Color(0xFF1E1E2C), fontSize = (12 * fontScale).sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Sign out button
            OutlinedButton(
                onClick = onSignOut,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_sign_out"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF5252)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF5252)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تسجيل الخروج من الحساب", fontSize = (13 * fontScale).sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ProfileStatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    accentColor: Color,
    fontScale: Float
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = value, color = TextPrimary, fontSize = (14 * fontScale).sp, fontWeight = FontWeight.Bold)
        Text(text = label, color = TextSecondary, fontSize = (10.5 * fontScale).sp)
    }
}
