package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SquadPlayer
import com.example.ui.theme.DarkAppBackground
import com.example.ui.theme.DarkAppBarColor
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SquadBuilderScreen(
    playersPool: List<SquadPlayer>,
    onBack: () -> Unit,
    onSubmitSquad: (rating: Int, chemistry: Int) -> Unit,
    fontScale: Float = 1.0f
) {
    BackHandler { onBack() }

    // Positions for 4-3-3 formation
    val positions = listOf(
        "GK" to "حارس مرمى",
        "DEF_1" to "ظهير أيمن",
        "DEF_2" to "قلب دفاع",
        "DEF_3" to "قلب دفاع",
        "DEF_4" to "ظهير أيسر",
        "MID_1" to "لاعب وسط",
        "MID_2" to "صانع ألعاب",
        "MID_3" to "ارتكاز",
        "FWD_1" to "جناح أيمن",
        "FWD_2" to "رأس حربة",
        "FWD_3" to "جناح أيسر"
    )

    val selectedSquad = remember { mutableStateMapOf<String, SquadPlayer>() }
    var activeSlotToFill by remember { mutableStateOf<String?>(null) }
    var squadEvaluated by remember { mutableStateOf(false) }

    val totalBudget = 100.0 // 100 Million
    val usedBudget = selectedSquad.values.sumOf { it.priceMillions }
    val remainingBudget = totalBudget - usedBudget

    val averageRating = if (selectedSquad.isNotEmpty()) {
        (selectedSquad.values.sumOf { it.rating } / selectedSquad.size)
    } else 0

    // Chemistry estimation based on shared clubs and leagues
    val chemistry = if (selectedSquad.size >= 4) {
        val clubsCount = selectedSquad.values.map { it.club }.distinct().size
        (100 - (clubsCount * 4)).coerceIn(40, 98)
    } else 0

    val sheetState = rememberModalBottomSheetState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkAppBackground)
            .testTag("squad_builder_screen")
    ) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = null,
                        tint = Color(0xFF64B5F6),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "كون فريق الأحلام (4-3-3)",
                        color = TextPrimary,
                        fontSize = (17 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack, modifier = Modifier.testTag("btn_back_squad")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = GoldPrimary
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkAppBarColor)
        )

        // Stats Dashboard Card (Rating, Chemistry, Budget)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Squad Rating
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "تقييم التشكيلة",
                        color = TextSecondary,
                        fontSize = (11 * fontScale).sp
                    )
                    Text(
                        text = if (averageRating > 0) "$averageRating OVR" else "--",
                        color = GoldPrimary,
                        fontSize = (18 * fontScale).sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(modifier = Modifier.width(1.dp).height(30.dp).background(DarkCardBorder))

                // Chemistry
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "التناغم الكروي",
                        color = TextSecondary,
                        fontSize = (11 * fontScale).sp
                    )
                    Text(
                        text = if (chemistry > 0) "$chemistry%" else "--",
                        color = NeonGreen,
                        fontSize = (18 * fontScale).sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(modifier = Modifier.width(1.dp).height(30.dp).background(DarkCardBorder))

                // Remaining Budget
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الميزانية المتبقية",
                        color = TextSecondary,
                        fontSize = (11 * fontScale).sp
                    )
                    Text(
                        text = "${String.format("%.1f", remainingBudget)}M$",
                        color = if (remainingBudget >= 0) TextPrimary else Color(0xFFFF5252),
                        fontSize = (16 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Pitch Representation with Slots
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp)
        ) {
            Text(
                text = "تشكيلة الـ 11 لاعباً (${selectedSquad.size}/11 مكتمل):",
                color = TextSecondary,
                fontSize = (13 * fontScale).sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(10.dp))

            positions.forEach { (slotKey, slotTitle) ->
                val filledPlayer = selectedSquad[slotKey]

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            activeSlotToFill = slotKey
                        }
                        .border(
                            1.dp,
                            if (filledPlayer != null) GoldPrimary.copy(alpha = 0.5f) else DarkCardBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .testTag("slot_$slotKey"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (filledPlayer != null) Color(0xFF222235) else DarkCardSurface
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (slotKey.startsWith("GK")) Color(0xFFFFB300)
                                else if (slotKey.startsWith("DEF")) Color(0xFF42A5F5)
                                else if (slotKey.startsWith("MID")) Color(0xFF66BB6A)
                                else Color(0xFFEF5350)
                            ) {
                                Text(
                                    text = slotKey.take(3),
                                    color = Color.Black,
                                    fontSize = (10 * fontScale).sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = filledPlayer?.name ?: slotTitle,
                                    color = if (filledPlayer != null) TextPrimary else TextMuted,
                                    fontSize = (14 * fontScale).sp,
                                    fontWeight = if (filledPlayer != null) FontWeight.Bold else FontWeight.Normal
                                )
                                if (filledPlayer != null) {
                                    Text(
                                        text = "${filledPlayer.club} | ${filledPlayer.nationality}",
                                        color = TextSecondary,
                                        fontSize = (11 * fontScale).sp
                                    )
                                }
                            }
                        }

                        if (filledPlayer != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${filledPlayer.rating} OVR",
                                    color = GoldPrimary,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { selectedSquad.remove(slotKey) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "حذف", tint = TextMuted)
                                }
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "إضافة لاعب",
                                    color = NeonGreen,
                                    fontSize = (12 * fontScale).sp
                                )
                                Icon(Icons.Default.Add, contentDescription = null, tint = NeonGreen)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Submit Button
            Button(
                onClick = {
                    squadEvaluated = true
                    onSubmitSquad(averageRating, chemistry)
                },
                enabled = selectedSquad.size >= 5 && remainingBudget >= 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_evaluate_squad"),
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (squadEvaluated) "تم حفظ واعتماد التشكيلة بنجاح! 🏆" else "اعتماد التشكيلة وتحدي الأصدقاء",
                    color = Color(0xFF1E1E2C),
                    fontSize = (14.5 * fontScale).sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Bottom sheet for selecting a player into slot
        if (activeSlotToFill != null) {
            val slot = activeSlotToFill!!
            val generalCategory = when {
                slot.startsWith("GK") -> "GK"
                slot.startsWith("DEF") -> "DEF"
                slot.startsWith("MID") -> "MID"
                else -> "FWD"
            }
            val suitablePlayers = playersPool.filter { it.position == generalCategory }

            ModalBottomSheet(
                onDismissRequest = { activeSlotToFill = null },
                sheetState = sheetState,
                containerColor = DarkAppBarColor
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "اختر لاعباً لمركز $generalCategory:",
                        color = GoldPrimary,
                        fontSize = (16 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(suitablePlayers) { p ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        selectedSquad[slot] = p
                                        activeSlotToFill = null
                                    }
                                    .border(1.dp, DarkCardBorder, RoundedCornerShape(10.dp)),
                                colors = CardDefaults.cardColors(containerColor = DarkCardSurface)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = p.name,
                                            color = TextPrimary,
                                            fontSize = (14 * fontScale).sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${p.club} | ${p.league}",
                                            color = TextSecondary,
                                            fontSize = (11 * fontScale).sp
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "${p.rating} OVR",
                                            color = GoldPrimary,
                                            fontSize = (14 * fontScale).sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${p.priceMillions}M$",
                                            color = NeonGreen,
                                            fontSize = (12 * fontScale).sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
