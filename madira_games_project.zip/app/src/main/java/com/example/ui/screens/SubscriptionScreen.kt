package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentTransaction
import com.example.ui.components.CopyablePaymentNumber
import com.example.ui.components.SecurityBadgeCard
import com.example.ui.theme.DarkAppBackground
import com.example.ui.theme.DarkAppBarColor
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkCardSurface
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.InstaPayPurple
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WalletOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    isVip: Boolean,
    recentTransactions: List<PaymentTransaction>,
    onProcessPayment: (method: String, targetNumber: String, senderNumber: String, refId: String) -> Unit,
    fontScale: Float = 1.0f
) {
    var selectedMethod by remember { mutableStateOf("Wallet") } // "Wallet" or "InstaPay"
    var senderNumberInput by remember { mutableStateOf("") }
    var referenceIdInput by remember { mutableStateOf("") }
    var showSuccessMessage by remember { mutableStateOf(false) }

    val walletTargetNumber = "01044581972"
    val instapayTargetNumber = "01228823207"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkAppBackground)
            .testTag("subscription_screen")
    ) {
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WorkspacePremium,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الاشتراك والترقية VIP",
                        color = TextPrimary,
                        fontSize = (18 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkAppBarColor)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Plan Card: 30 EGP / monthly
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("subscription_plan_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = androidx.compose.foundation.BorderStroke(2.dp, GoldPrimary)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = GoldPrimary.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Text(
                            text = if (isVip) "⭐ أنت حالياً مشترك VIP نشط" else "الباقة الاحترافية الذهبية",
                            color = GoldPrimary,
                            fontSize = (12.5 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "30",
                            color = GoldPrimary,
                            fontSize = (38 * fontScale).sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "جنيه مصري / شهرياً",
                            color = TextPrimary,
                            fontSize = (16 * fontScale).sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Benefits list
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1E1E2C))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BenefitRow("دخول غير محدود لجميع التحديات الكروية بدون إعلانات", fontScale)
                        BenefitRow("شارة VIP الذهبية 👑 تظهر بجانب اسمك في لوحة المتصدرين", fontScale)
                        BenefitRow("مضاعفة نقاط الفوز والخبرة (Double XP) للصدارة السريعة", fontScale)
                        BenefitRow("تحليلات وتوقعات حصرية لبورصة اللاعبين لمضاعفة أرباحك", fontScale)
                        BenefitRow("المشاركة في بطولات الأصدقاء الأسبوعية المغلقة وجوائزها", fontScale)
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Security & Sensitive Data Encryption Guarantee Card as requested
            SecurityBadgeCard(fontScale = fontScale)

            Spacer(modifier = Modifier.height(18.dp))

            // Payment Options Title
            Text(
                text = "اختر طريقة الدفع الإلكتروني:",
                color = TextPrimary,
                fontSize = (15 * fontScale).sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 1. Mobile Wallet (Vodafone / Orange / Etisalat / WE Cash) on 01044581972
            CopyablePaymentNumber(
                title = "الدفع عبر المحفظة الإلكترونية (كاش)",
                phoneNumber = walletTargetNumber,
                providerBadge = "فودافون • أورنج • اتصالات • WE",
                badgeColor = WalletOrange,
                fontScale = fontScale
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 2. InstaPay on 01228823207
            CopyablePaymentNumber(
                title = "الدفع عبر تطبيق إنستاباي (InstaPay)",
                phoneNumber = instapayTargetNumber,
                providerBadge = "InstaPay فوري",
                badgeColor = InstaPayPurple,
                fontScale = fontScale
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Payment Confirmation Form
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("payment_confirmation_form"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCardSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "تأكيد التحويل وتفعيل الحساب:",
                        color = GoldPrimary,
                        fontSize = (14 * fontScale).sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Method selector buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedMethod = "Wallet" }
                                .border(
                                    1.dp,
                                    if (selectedMethod == "Wallet") WalletOrange else DarkCardBorder,
                                    RoundedCornerShape(8.dp)
                                ),
                            color = if (selectedMethod == "Wallet") WalletOrange.copy(alpha = 0.2f) else Color(0xFF1E1E2C)
                        ) {
                            Text(
                                text = "محفظة كاش 📱",
                                color = if (selectedMethod == "Wallet") WalletOrange else TextSecondary,
                                fontSize = (12 * fontScale).sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedMethod = "InstaPay" }
                                .border(
                                    1.dp,
                                    if (selectedMethod == "InstaPay") InstaPayPurple else DarkCardBorder,
                                    RoundedCornerShape(8.dp)
                                ),
                            color = if (selectedMethod == "InstaPay") InstaPayPurple.copy(alpha = 0.2f) else Color(0xFF1E1E2C)
                        ) {
                            Text(
                                text = "إنستاباي InstaPay ⚡",
                                color = if (selectedMethod == "InstaPay") InstaPayPurple else TextSecondary,
                                fontSize = (12 * fontScale).sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "رقم هاتفك أو حسابك المحوِّل منه:",
                        color = TextSecondary,
                        fontSize = (12 * fontScale).sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = senderNumberInput,
                        onValueChange = { senderNumberInput = it },
                        placeholder = { Text("مثال: 010XXXXXXXX", color = TextMuted) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_sender_number"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "رقم المعاملة أو كود العملية (المرجعي):",
                        color = TextSecondary,
                        fontSize = (12 * fontScale).sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = referenceIdInput,
                        onValueChange = { referenceIdInput = it },
                        placeholder = { Text("مثال: TXN-8941235", color = TextMuted) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_reference_id"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = DarkCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val target = if (selectedMethod == "Wallet") walletTargetNumber else instapayTargetNumber
                            val sender = if (senderNumberInput.isNotBlank()) senderNumberInput else "01000000000"
                            val ref = if (referenceIdInput.isNotBlank()) referenceIdInput else "REF-${System.currentTimeMillis().toString().takeLast(6)}"
                            onProcessPayment(selectedMethod, target, sender, ref)
                            showSuccessMessage = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_submit_payment"),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFF1E1E2C), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تأكيد الدفع المشفر (30 ج.م شهرياً)",
                                color = Color(0xFF1E1E2C),
                                fontSize = (14 * fontScale).sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(visible = showSuccessMessage || isVip) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1B5E20),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "تم تفعيل اشتراك VIP الشهري بنجاح! 👑",
                                    color = Color.White,
                                    fontSize = (13.5 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "تم إضافة 500 نقطة خبرة وشارة التميز إلى ملفك الشخصي.",
                                    color = Color(0xFFE8F5E9),
                                    fontSize = (11.5 * fontScale).sp
                                )
                            }
                        }
                    }
                }
            }

            // Recent Transactions
            if (recentTransactions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "سجل العمليات السابقة:",
                    color = TextSecondary,
                    fontSize = (13 * fontScale).sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))

                recentTransactions.forEach { txn ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF242436))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${txn.method} • ${txn.amountEgp} ج.م",
                                    color = TextPrimary,
                                    fontSize = (13 * fontScale).sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "المرجع: ${txn.referenceId}",
                                    color = TextMuted,
                                    fontSize = (11 * fontScale).sp
                                )
                            }
                            Text(
                                text = txn.status,
                                color = NeonGreen,
                                fontSize = (11 * fontScale).sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun BenefitRow(text: String, fontScale: Float) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            color = TextPrimary,
            fontSize = (12 * fontScale).sp
        )
    }
}
