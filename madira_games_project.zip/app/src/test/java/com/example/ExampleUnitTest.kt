package com.example

import com.example.data.model.ChallengeIconType
import com.example.data.repository.AppDataRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun repository_initialChallenges_containsFourCoreChallenges() {
        val repository = AppDataRepository()
        val challenges = repository.challenges.value

        assertEquals(4, challenges.size)

        // Verify the 4 exact requested challenges exist with their icons:
        // 1. خمن اسم اللاعب (PERSON)
        val playerChallenge = challenges.find { it.id == "guess_player" }
        assertNotNull(playerChallenge)
        assertEquals("خمن اسم اللاعب", playerChallenge?.title)
        assertEquals(ChallengeIconType.PERSON, playerChallenge?.iconType)

        // 2. خمن اسم النادي (SOCCER)
        val clubChallenge = challenges.find { it.id == "guess_club" }
        assertNotNull(clubChallenge)
        assertEquals("خمن اسم النادي", clubChallenge?.title)
        assertEquals(ChallengeIconType.SOCCER, clubChallenge?.iconType)

        // 3. كون فريق (GROUPS)
        val squadChallenge = challenges.find { it.id == "squad_builder" }
        assertNotNull(squadChallenge)
        assertEquals("كون فريق", squadChallenge?.title)
        assertEquals(ChallengeIconType.GROUPS, squadChallenge?.iconType)

        // 4. تحدي البورصة (TRENDING_UP)
        val stockChallenge = challenges.find { it.id == "stock_market" }
        assertNotNull(stockChallenge)
        assertEquals("تحدي البورصة", stockChallenge?.title)
        assertEquals(ChallengeIconType.TRENDING_UP, stockChallenge?.iconType)
    }

    @Test
    fun repository_toggleFavorite_updatesState() {
        val repository = AppDataRepository()
        val initialFavorite = repository.challenges.value.first { it.id == "guess_player" }.isFavorite

        repository.toggleFavorite("guess_player")
        val updatedFavorite = repository.challenges.value.first { it.id == "guess_player" }.isFavorite

        assertEquals(!initialFavorite, updatedFavorite)
    }

    @Test
    fun repository_subscriptionFlow_activatesVipAndRecordsTransaction() {
        val repository = AppDataRepository()
        assertFalse(repository.currentUser.value.isVip)

        val txn = repository.processSubscription(
            method = "Wallet",
            targetNumber = "01044581972",
            senderNumber = "01012345678",
            referenceId = "REF_998877"
        )

        assertEquals("01044581972", txn.targetNumber)
        assertEquals(30, txn.amountEgp)
        assertTrue(repository.currentUser.value.isVip)
        assertTrue(repository.transactions.value.contains(txn))
    }

    @Test
    fun repository_stockTrading_updatesSharesAndCoins() {
        val repository = AppDataRepository()
        val initialCoins = repository.currentUser.value.virtualCoins
        val stock = repository.stocks.value.first()

        val bought = repository.buyStock(stock.id, 1)
        assertTrue(bought)
        assertEquals(initialCoins - stock.currentPriceEgp, repository.currentUser.value.virtualCoins, 0.01)

        val sold = repository.sellStock(stock.id, 1)
        assertTrue(sold)
        assertEquals(initialCoins, repository.currentUser.value.virtualCoins, 0.01)
    }

    @Test
    fun levelingSystem_calculatesLevelAndTierProgressCorrectly() {
        val userWithZeroPoints = com.example.data.model.UserProfile(points = 0)
        val progressZero = userWithZeroPoints.levelProgress
        assertEquals(1, progressZero.level)
        assertEquals("tier_rookie", progressZero.currentTier.tierId)
        assertEquals(250, progressZero.pointsToNextLevel)
        assertEquals(0.0f, progressZero.levelProgressRatio, 0.001f)

        // 2850 points
        val userMid = com.example.data.model.UserProfile(points = 2850)
        val progressMid = userMid.levelProgress
        assertEquals(12, progressMid.level)
        assertEquals("tier_star", progressMid.currentTier.tierId)
        assertEquals("نجم الفريق", progressMid.currentTier.titleAr)
        assertEquals("tier_captain", progressMid.nextTier?.tierId)
        assertEquals(150, progressMid.pointsToNextLevel)
        assertEquals(3000, progressMid.levelNextPoints)
        assertTrue(progressMid.levelProgressRatio in 0.0f..1.0f)
        assertTrue(progressMid.tierProgressRatio in 0.0f..1.0f)
        assertEquals(4500 - 2850, progressMid.pointsToNextTier)

        // High points -> Ballon d'or tier
        val userLegend = com.example.data.model.UserProfile(points = 15000)
        val progressLegend = userLegend.levelProgress
        assertEquals("tier_ballon_dor", progressLegend.currentTier.tierId)
        assertEquals(null, progressLegend.nextTier)
    }
}

